<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('title', 'Create New Category'); ?>




<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-between">
        <h6 class="mb-0 text-uppercase"> Categories </h6>
        <a class="btn btn-success" href="<?php echo e(route('categories.index')); ?>"> ALl Category </a>
    </div>
    <hr/>
    <div class="card">
        <div class="card-body">

            <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input name="name" type="text" class="form-control" id="name">
                            <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('name'))?($errors->first('name')):''); ?></div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input name="image" type="file" class="form-control" id="image">
                            <div style='color:red; padding: 0 5px;'><?php echo e(($errors->has('image'))?($errors->first('image')):''); ?></div>

                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>


        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/backend/categories/create.blade.php ENDPATH**/ ?>
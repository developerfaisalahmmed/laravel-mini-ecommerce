<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">


                    <?php if(Cart::getTotal() > 0): ?>

                    <table class="table">
                        <thead>
                        <tr>
                            <th> Image</th>
                            <th> Name</th>
                            <th> Qtd</th>
                            <th> Quantity</th>
                            <th> price</th>
                            <th> Remove</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img style="width: 200px;height: 50px" src="<?php echo e($item->attributes->image); ?>" class=""
                                         alt="Thumbnail">
                                </td>
                                <td><?php echo e($item->name); ?></td>
                                <td>
                                    <form action="<?php echo e(route('cart.update')); ?>" method="POST"
                                          class="d-flex justify-content-between">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                        <input class="btn-height" type="number" name="quantity" min="1" value="<?php echo e($item->quantity); ?>"/>
                                        <button class="btn btn-sm btn-success btn-height">Update</button>
                                    </form>
                                </td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>৳<?php echo e($item->price); ?></td>
                                <td>
                                    <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                        <button class="btn btn-sm btn-success btn-height">x</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-between py-5">

                        <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-info btn-height">Clear Carts </button>
                        </form>

                        <form>
                            <button class="btn btn-sm btn-warning btn-height"> Total : ৳ <?php echo e(Cart::getTotal()); ?> </button>
                        </form>

                        <form>
                            <button class="btn btn-sm btn-success btn-height"> Checkout </button>
                        </form>

                    </div>
                    <?php else: ?>
                        <div class="py-5">
                            <p class="text-center p-3 bg-dark text-danger"> No items found in your cart </p>
                        </div>
                  <?php endif; ?>
                </div>
            </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/frontend/cart.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <section>
            <div class="hp-mod-card card-jfy J_JFY J_NavChangeHook">
                
                <div class="hp-mod-card-header d-flex justify-content-between">
                    <a class="">/Home/Category/<?php echo e($category_products->name); ?></a>
                </div>

                <div class="hp-mod-card-content J_JFYCard">
                    <div class="card-jfy-grid J_JFYItems">
                        <div class="card-jfy-wrapper">

                            <div class="card-jfy-row J_Row1">
                                <?php $__currentLoopData = $category_products->category_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card-jfy-item-wrapper hp-mod-card-hover J_Items inline my-2">
                                        <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                                            <div class="card-jfy-item">

                                                <div class="card-jfy-image card-jfy-image-background J_GridImage">
                                                    <img class="image" src="<?php echo e(asset($product->first_book[0]['image']) ?? 'Null'); ?>" alt="">
                                                </div>

                                                <div class="card-jfy-item-desc">

                                                    <div class="card-jfy-segment">
                                                    </div>


                                                    <div class="card-jfy-title"><span class="title"><?php echo e($product->title); ?></span></div>


                                                    <div class="hp-mod-price">

                                                        <div class="hp-mod-price-first-line">
                                                            <span class="currency">৳</span><span class="price"><?php echo e($product->selling_price); ?></span>
                                                        </div>

                                                        <div class="hp-mod-price-second-line"><span class="hp-mod-price-text align-left">
                                                    <span class="currency">৳</span><span class="price"><?php echo e($product->price); ?></span></span>
                                                            <span class="hp-mod-discount align-left">
                                                                 <?php if($product->discount_type == 1): ?>
                                                                    ৳<?php echo e($product->discount); ?>

                                                                <?php else: ?>
                                                                    <?php echo e($product->discount); ?>%
                                                                <?php endif; ?>
                                                            </span></div>
                                                    </div>


                                                    

                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    


                                                    

                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>

                </div>
                
            </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/frontend/category_products.blade.php ENDPATH**/ ?>
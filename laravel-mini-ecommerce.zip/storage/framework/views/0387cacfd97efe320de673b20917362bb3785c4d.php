<?php $__env->startSection('content'); ?>

    <section>

        <div class="container py-2">
            <div class="">
                <a class="">/Home/Category/<?php echo e($category_products->name); ?> </a>
            </div>
            <div class="row">
                <?php $__currentLoopData = $category_products->category_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-3 col-lg-3 py-1">
                        <a href="<?php echo e(route('product.details',$product->slug)); ?>">
                            <div class="card">
                                <img src="<?php echo e($product->first_image[0]['image'] ?? 'Null'); ?>" alt="<?php echo e($product->title); ?>">
                                <div class="card-body">
                                    <h6 class="card-text"><strong><?php echo e($product->title); ?></strong></h6>
                                    <h6 class="card-text"><strong> ৳<?php echo e($product->selling_price); ?> </strong> <sup>
                                            <del>৳<?php echo e($product->price); ?></del>
                                            <?php if($product->discount_type == 1): ?>
                                                ৳<?php echo e($product->discount); ?>

                                            <?php else: ?>
                                                <?php echo e($product->discount); ?>%
                                            <?php endif; ?>
                                        </sup></h6>

                                    <div class="py-1 d-flex justify-content-between">
                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(route('wishlist')); ?>" method="POST"
                                                  enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">

                                                <button class="btn btn-sm btn-warning btn-height" tabindex="0">
                                                    <i class="fa fa-heart"></i> Favourite
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('cart.store')); ?>" method="POST"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                            <input type="hidden" value="<?php echo e($product->title); ?>" name="name">
                                            <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                            <input type="hidden"
                                                   value="<?php echo e(asset($product->first_image[0]['image']) ?? 'Null'); ?>"
                                                   name="image">
                                            <input type="hidden" value="1" name="quantity">
                                            <button class="btn btn-sm btn-success btn-height" tabindex="0">
                                                <i class="fa fa-shopping-cart"></i> Add to Cart
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/frontend/category_products.blade.php ENDPATH**/ ?>
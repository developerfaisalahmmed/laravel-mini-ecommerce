<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <?php if($products->count() > 0): ?>
                        <table class="table">
                            <thead>
                            <tr>
                                <th> Image</th>
                                <th> Name</th>
                                <th> price</th>
                                <th> Add to Cart</th>
                                <th> Remove</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img style="width: 200px;height: 50px"
                                             src="<?php echo e(asset($product->wishlistList->first_image[0]['image']) ?? 'Null'); ?>"
                                             class=""
                                             alt="<?php echo e($product->wishlistList->title); ?>">
                                    </td>
                                    <td><?php echo e($product->wishlistList->title); ?></td>
                                    <td>৳<?php echo e($product->wishlistList->price); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('cart.store')); ?>" method="POST"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($product->wishlistList->id); ?>" name="id">
                                            <input type="hidden" value="<?php echo e($product->wishlistList->title); ?>"
                                                   name="name">
                                            <input type="hidden" value="<?php echo e($product->wishlistList->price); ?>"
                                                   name="price">
                                            <input type="hidden"
                                                   value="<?php echo e(asset($product->wishlistList->first_image[0]['image']) ?? 'Null'); ?>"
                                                   name="image">
                                            <input type="hidden" value="1" name="quantity">
                                            <button class="btn btn-sm btn-success btn-height" tabindex="0">
                                                <i class="fa fa-shopping-cart"></i> Add to Cart
                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <a class="btn btn-sm btn-success btn-height"
                                           href="<?php echo e(route('wishlist.remove',$product->id)); ?>">x</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="d-flex justify-content-end py-3">
                            <a class="btn btn-sm btn-success btn-height" href="<?php echo e(route('wishlist.clear')); ?>">Clear
                                Wishlist</a>
                        </div>

                    <?php else: ?>
                        <div class="py-5">
                            <p class="text-center p-3 bg-dark text-danger"> No items found in your wishlists </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/frontend/wishlists.blade.php ENDPATH**/ ?>
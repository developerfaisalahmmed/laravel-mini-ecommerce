<footer class="page-footer">
    <p class="mb-0">Copyright © 2021. All right reserved.</p>
</footer>
<?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
<?php $__env->startPush('css'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/dist/xzoom.css" media="all"/>
    <link type="text/css" rel="stylesheet" media="all" href="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/magnific-popup/css/magnific-popup.css"/>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <section>
        <div class="hp-mod-card card-jfy J_JFY J_NavChangeHook">
            <div class="hp-mod-card-header d-flex justify-content-between">
                <a class="" href="">/Home/Product is <?php echo e($product->title); ?></a>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="card pt-3">
                        <div class="xzoom-container">
                            <img height="200px" class="xzoom5" id="xzoom-magnific"
                                 src="<?php echo e(asset($product->first_book[0]['image']) ?? 'Null'); ?> "
                                 xoriginal="<?php echo e(asset($product->first_book[0]['image']) ?? 'Null'); ?> "/>
                            <div class="xzoom-thumbs">
                                <?php $__currentLoopData = $product->productImages ?? 'null'; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(asset($product_image->image ?? 'Null')); ?>">
                                        <img class="xzoom-gallery5" width="80" src="<?php echo e(asset($product_image->image ?? 'Null')); ?>" xpreview="<?php echo e(asset($product_image->image ?? 'Null')); ?>" title="The description goes here">
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->title); ?></h5>
                            <p class="card-text"><?php echo $product->description; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="_product-detail-content">
                        <p class="_p-name"> Milton Bottle </p>
                        <div class="_p-price-box">
                            <div class="p-list">
                                <span> M.R.P. : <i class="fa fa-inr"></i> <del> 1399  </del>   </span>
                                <span class="price"> Rs. 699 </span>
                            </div>
                            <div class="_p-add-cart">
                                <div class="_p-qty">
                                    <span>Add Quantity</span>

                                    <input type="number" name="qty" id="number" value="1" min="1" />

                                </div>
                            </div>
                            <form action="" method="post" accept-charset="utf-8">
                                <ul class="spe_ul"></ul>
                                <div class="_p-qty-and-cart">
                                    <div class="_p-add-cart">
                                        <button class="btn-theme btn buy-btn" tabindex="0">
                                            <i class="fa fa-shopping-cart"></i> Buy Now
                                        </button>
                                        <button class="btn-theme btn btn-success" tabindex="0">
                                            <i class="fa fa-shopping-cart"></i> Add to Cart
                                        </button>
                                        <input type="hidden" name="pid" value="18" />
                                        <input type="hidden" name="price" value="850" />
                                        <input type="hidden" name="url" value="" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>

    <script type="text/javascript" src="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/js/vendor/jquery.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/dist/xzoom.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/magnific-popup/js/magnific-popup.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/product-gallery-with-image-zoom-xzoom')); ?>/js/setup.js"></script>

    <script>
        $('.decrease_').click(function () {
            decreaseValue(this);
        });
        $('.increase_').click(function () {
            increaseValue(this);
        });
        function increaseValue(_this) {
            var value = parseInt($(_this).siblings('input#number').val(), 10);
            value = isNaN(value) ? 0 : value;
            value++;
            $(_this).siblings('input#number').val(value);
        }

        function decreaseValue(_this) {
            var value = parseInt($(_this).siblings('input#number').val(), 10);
            value = isNaN(value) ? 0 : value;
            value < 1 ? value = 1 : '';
            value--;
            $(_this).siblings('input#number').val(value);
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/frontend/product_details.blade.php ENDPATH**/ ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('title', 'Categories'); ?>




<?php $__env->startSection('content'); ?>


<div class="d-flex justify-content-between">
    <h6 class="mb-0 text-uppercase"> Categories </h6>
   <a class="btn btn-success" href="<?php echo e(route('categories.create')); ?>"> New Category </a>
</div>
    <hr/>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="example2" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Created Time</th>
                        <th>Update Time</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td> <img width="100px" height="31px" src="<?php echo e(asset($category->image) ?? 'Null'); ?>"> </td>
                        <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($category->updated_at->diffForHumans()); ?></td>
                        <td class="d-flex">
                            <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-sm" ><i class="lni lni-highlight-alt"></i></a>

                            <form action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm" type="submit"><i class="lni lni-cross-circle"></i></button>

                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Created Time</th>
                        <th>Update Time</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LEARN LARAVEL\laravel-mini-ecommerce\resources\views/backend/categories/index.blade.php ENDPATH**/ ?>